package com.elasticsearch.search.controller;

import com.elasticsearch.search.api.facade.SearchApi;
import com.elasticsearch.search.api.model.Result;
import com.elasticsearch.search.service.SearchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@CrossOrigin("*")
@RestController
@RequestMapping("/search")
public class SearchController implements SearchApi {

    private SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    //http://localhost:8080/wikiexplorer/search?query=square&page=3
    @GetMapping
    public CompletableFuture<ResponseEntity<List<Result>>> search(@RequestParam("query") String query,
                                                                  @RequestParam(value = "page", defaultValue = "1") int page){
        var results = searchService.submitQuery(query, page);
        return CompletableFuture.supplyAsync(() -> ResponseEntity.ok(results));
    }
}
