package com.elasticsearch.search.controller;

import com.elasticsearch.search.api.facade.SearchApi;
import com.elasticsearch.search.api.model.Result;
import com.elasticsearch.search.service.SearchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@CrossOrigin("*")
@RestController
@RequestMapping("/search")
public class SearchController implements SearchApi {

    private SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    //http://localhost:8080/wikiexplorer/search?query=square&page=3
    /**
     * Pesquisa no Elasticsearch com base nos parâmetros fornecidos.
     *
     * @param query A string de consulta a ser pesquisada.
     * @param page O número da página de resultados a ser recuperada (padrão: 1).
     * @param sortOrder A ordem de classificação dos resultados (padrão: 3).
     *                  1 para ascendente, 2 para descendente, 3 para padrão(score).
     * @param sortBy O campo pelo qual os resultados devem ser ordenados (padrão: "content").
     * @param sortOptions Opções de ordenação: >, <, ==, >=, <=. (padrão: greather / >).
     * @param queryType Indica qual o tipo desejado da query (padrão: 1).
     *                  1 para matchQuery, 2 para matchPhrase, 3 para boolQuery
     *
     */
    @GetMapping
    public CompletableFuture<ResponseEntity<List<Result>>> search(@RequestParam("query") String query,
                                                                  @RequestParam(value = "page", defaultValue = "1") int page,
                                                                  @RequestParam(value = "sortOrder", defaultValue = "3") int sortOrder,
                                                                  @RequestParam(value = "sortBy", defaultValue = "content") String sortBy,
                                                                  @RequestParam(value = "sortOptions", defaultValue = "greather") String sortOptions,
                                                                  @RequestParam(value = "queryType", defaultValue = "1") int queryType
                                                                  ){
        var results = searchService.submitQuery(query, page, sortOrder, sortBy, queryType, sortOptions);
        return CompletableFuture.supplyAsync(() -> ResponseEntity.ok(results));
    }
}
