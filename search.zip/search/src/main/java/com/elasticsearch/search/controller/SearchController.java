package com.elasticsearch.search.controller;

import com.elasticsearch.search.api.facade.SearchApi;
import com.elasticsearch.search.api.model.Result;
import com.elasticsearch.search.service.SearchService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.CompletableFuture;

@CrossOrigin("*")
@RestController
@RequestMapping("/search")
public class SearchController implements SearchApi {

    private SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    //http://localhost:8080/wikiexplorer/search?query=square&page=3
    /**
     * Pesquisa no Elasticsearch com base nos parâmetros fornecidos.
     *
     * @param query A string de consulta a ser pesquisada.
     * @param page O número da página de resultados a ser recuperada (padrão: 1).
     * @param sortOrder A ordem de classificação dos resultados (padrão: 3).
     *                  ASC para ascendente, DESC para descendente, NORMAL para padrão(score).
     * @param sortBy O campo pelo qual os resultados devem ser ordenados (padrão: "content").
     * @param rangeOptions Opções de ordenação
     *                     1° -> por qual campo ordenar ? (reading_time ou dt_creation)
     *                     2° -> quantos operadores usar ? (1 ou 2)
     *                     3° -> primeiro operador que deseja (gt, gte, lt, lte)
     *                     4° -> valor que deseja coparar a ordenação (5 ou 2019-10-21 por ex)
     *                     5° -> segundo operador que deseja (0 caso não tiver)
     *                     6° -> segundo valor que deseja (0 caso não tiver)
     *                     (padrão: reading_time/1/gt/5/0/0).
     * @param queryType Indica qual o tipo desejado da query (padrão: 1).
     *                  1 para matchQuery ou para matchPhrase, 2 para boolQuery, 3 rangeQuery
     * @param boolOptions Indica quais as opções da BoolQuery (padrão: 1/number/0/0)
     *                   1° -> código da operação
     *                      1 -> apenas must
     *                      2 -> apenas should
     *                      3 -> apenas must_not
     *                      4 -> must e should
     *                      5 -> must e must_not
     *                      6 -> sould e must_not
     *                      7 -> must, should e must_not
     *                   2°, 3° e 4° -> querys
     *
     *                   Must, Should, Not (must_not)
     */
    @GetMapping
    public CompletableFuture<ResponseEntity<List<Result>>> search(@RequestParam("query") String query,
                                                                  @RequestParam(value = "page", defaultValue = "1") int page,
                                                                  @RequestParam(value = "sortOrder", defaultValue = "NORMAL") String sortOrder,
                                                                  @RequestParam(value = "sortBy", defaultValue = "content") String sortBy,
                                                                  @RequestParam(value = "rangeOptions", defaultValue = "reading_time/1/gt/5/0/0") String rangeOptions,
                                                                  @RequestParam(value = "queryType", defaultValue = "1") int queryType,
                                                                  @RequestParam(value = "boolOptions", defaultValue = "1/number/0/0") String boolOptions
                                                                  ){
        var results = searchService.submitQuery(query, page, sortOrder, sortBy, queryType, rangeOptions, boolOptions);
        return CompletableFuture.supplyAsync(() -> ResponseEntity.ok(results));
    }
}
