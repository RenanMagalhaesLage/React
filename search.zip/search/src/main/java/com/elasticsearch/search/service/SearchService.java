package com.elasticsearch.search.service;

import co.elastic.clients.elasticsearch.core.search.*;
import com.elasticsearch.search.api.model.Result;
import com.elasticsearch.search.domain.EsClient;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class SearchService {

    private final EsClient esClient;

    public SearchService(EsClient esClient) {
        this.esClient = esClient;
    }

    public List<Result> submitQuery(String query, int page, String sortOrder, String sortBy, int queryType, String rangeOptions, String boolOption) {
        var searchResponse = esClient.search(query,page, sortOrder, sortBy, queryType, rangeOptions, boolOption);
        List<Hit<ObjectNode>> hits = searchResponse.hits().hits();
        getTotalHits(query, page, sortOrder, sortBy, queryType, rangeOptions, boolOption); //Total de resultados


        var resultsList = hits.stream().map(h ->
                new Result()
                        .abs(treatContent(h.source().get("content").asText()))
                        .title(h.source().get("title").asText())
                        .url(h.source().get("url").asText())
                        .readingTime(h.source().get("reading_time").asText())
                        .dtCreation(h.source().get("dt_creation").asText())
        ).collect(Collectors.toList());

        return resultsList;
    }

    public long getTotalHits(String query, int page, String sortOrder, String sortBy, int queryType, String rangeOptions, String boolOption) {
        var searchResponse = esClient.search(query, page, sortOrder, sortBy, queryType, rangeOptions, boolOption);
        long totalHits = searchResponse.hits().total().value();
        //System.out.printf(totalHits + " total hits");
        return totalHits;
    }

    private String treatContent(String content) {
        content = content.replaceAll("</?(som|math)\\d*>", "");
        content = content.replaceAll("[^A-Za-z\\s]+", "");
        content = content.replaceAll("\\s+", " ");
        content = content.replaceAll("^\\s+", "");
        return content;
    }
}
