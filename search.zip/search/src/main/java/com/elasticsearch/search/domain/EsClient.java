package com.elasticsearch.search.domain;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.FieldSort;
import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.query_dsl.*;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.json.JsonData;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import nl.altindag.ssl.SSLFactory;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.client.RestClient;
//import org.elasticsearch.index.query.BoolQueryBuilder;
//import org.elasticsearch.index.query.MatchQueryBuilder;
import org.springframework.stereotype.Component;


import java.io.IOException;
import java.time.LocalDate;
import java.util.Objects;

@Component
public class EsClient {
    private ElasticsearchClient elasticsearchClient;

    public EsClient() {
        createConnection();
    }

    private void createConnection() {
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();

        String USER = "elastic";
        String PWD = "user123";
        credentialsProvider.setCredentials(AuthScope.ANY,
            new UsernamePasswordCredentials(USER, PWD));

        SSLFactory sslFactory = SSLFactory.builder()
            .withUnsafeTrustMaterial()
            .withUnsafeHostnameVerifier()
            .build();

        RestClient restClient = RestClient.builder(
                new HttpHost("localhost", 9200, "https"))
            .setHttpClientConfigCallback((HttpAsyncClientBuilder httpClientBuilder) -> httpClientBuilder
                .setDefaultCredentialsProvider(credentialsProvider)
                .setSSLContext(sslFactory.getSslContext())
                .setSSLHostnameVerifier(sslFactory.getHostnameVerifier())
            ).build();

        ElasticsearchTransport transport = new RestClientTransport(
            restClient,
            new JacksonJsonpMapper()
        );

        elasticsearchClient = new ElasticsearchClient(transport);
    }

    public SearchResponse search(String query, int page, String sortOrder, String sortBy, int queryType, String rangeOptions, String boolOption) {
        //                                             Buscando no campo content
        Query matchQuery = MatchQuery.of(q -> q.field("content").query(query))._toQuery();
        Query matchPhrase = MatchPhraseQuery.of(q -> q.field("content").query(query))._toQuery();

        int size = 10;
        int from = size*(page - 1);

        String fieldRange = rangeOptions.split("/")[0];
        String quantRange = rangeOptions.split("/")[1];
        String firstSinalRange = rangeOptions.split("/")[2];
        String firstRange = rangeOptions.split("/")[3];
        String secondSinalRange = rangeOptions.split("/")[4];
        String secondRange = rangeOptions.split("/")[5];

        /*
        System.out.println(fieldRange  );
        System.out.println(quantRange );
        System.out.println(firstSinalRange );
        System.out.println(firstRange );
        System.out.println(secondSinalRange );
        System.out.println(secondRange );
        */

        /*BoolQuery.Builder boolQueryBuilder = new BoolQuery.Builder();
        Query boolQuery = MatchQuery.of(q -> q.field("content").query(query))._toQuery();
        boolQueryBuilder.must(boolQuery);*/
        //COM BOOL QUERY BUILDER
                    /*response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(q -> q
                                    .bool(boolQueryBuilder.build())
                            ).sort(so -> so
                                    .field(FieldSort.of(f -> f
                                            .field(sortBy)
                                            .order(SortOrder.Desc))
                                    )), ObjectNode.class
                    );*/

        SearchResponse<ObjectNode> response = null;
        try {
            if(queryType == 2){ // MatchPhrase
                if(Objects.equals(sortOrder, "ASC")) {
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchPhrase).sort(so -> so
                                    .field(FieldSort.of(f -> f
                                            .field(sortBy)
                                            .order(SortOrder.Asc))
                                    )), ObjectNode.class
                    );
                } else if (Objects.equals(sortOrder, "DESC")) {
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchPhrase).sort(so -> so
                                    .field(FieldSort.of(f -> f
                                            .field(sortBy)
                                            .order(SortOrder.Desc))
                                    )), ObjectNode.class
                    );
                }else { //NORMAL / PADRÃO - score
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchPhrase), ObjectNode.class
                    );
                }

            } else if (queryType == 3) { // BoolQuery
                if(Objects.equals(boolOption, "Should")){
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(q -> q.bool(bq -> bq
                                    .should(matchQuery)
                            )), ObjectNode.class
                    );
                }else if (Objects.equals(boolOption, "Not")) {
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(q -> q.bool(bq -> bq
                                    .mustNot(matchQuery)
                            )), ObjectNode.class
                    );
                }else { //MUST
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(q -> q.bool(bq -> bq
                                    .must(matchQuery)
                            )), ObjectNode.class
                    );
                }
              }else if (queryType == 4){ // RangeQuery
                if(Objects.equals(firstSinalRange, "2")){
                    if(Objects.equals(firstSinalRange, "gte") && Objects.equals(secondSinalRange, "lte")){
                        response = elasticsearchClient.search(s -> s
                                .index("wikipedia").from(from).size(size)
                                .query(q -> q.bool(bq -> bq
                                        .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                .gte(JsonData.of(firstRange))
                                                .lte(JsonData.of(secondRange))
                                        ))
                                        .must(matchQuery)
                                )), ObjectNode.class
                        );
                    }else if (Objects.equals(firstSinalRange, "gte") && Objects.equals(secondSinalRange, "lt")) {
                        response = elasticsearchClient.search(s -> s
                                .index("wikipedia").from(from).size(size)
                                .query(q -> q.bool(bq -> bq
                                        .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                .gte(JsonData.of(firstRange))
                                                .lt(JsonData.of(secondRange))
                                        ))
                                        .must(matchQuery)
                                )), ObjectNode.class
                        );
                    }else if (Objects.equals(firstSinalRange, "gt") && Objects.equals(secondSinalRange, "lt")){
                        response = elasticsearchClient.search(s -> s
                                .index("wikipedia").from(from).size(size)
                                .query(q -> q.bool(bq -> bq
                                        .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                .gt(JsonData.of(firstRange))
                                                .lt(JsonData.of(secondRange))
                                        ))
                                        .must(matchQuery)
                                )), ObjectNode.class
                        );
                    }else if (Objects.equals(firstSinalRange, "gt") && Objects.equals(secondSinalRange, "lte")){
                        response = elasticsearchClient.search(s -> s
                                .index("wikipedia").from(from).size(size)
                                .query(q -> q.bool(bq -> bq
                                        .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                .gt(JsonData.of(firstRange))
                                                .lte(JsonData.of(secondRange))
                                        ))
                                        .must(matchQuery)
                                )), ObjectNode.class
                        );
                    }
                }else{
                    if(Objects.equals(firstSinalRange, "gte")){
                           response = elasticsearchClient.search(s -> s
                                .index("wikipedia").from(from).size(size)
                                .query(q -> q.bool(bq -> bq
                                        .filter(fb -> fb.range(r -> r.field(fieldRange).
                                                gte(JsonData.of(firstRange))
                                        ))
                                        .must(matchQuery)
                                )), ObjectNode.class
                        );
                    }else if (Objects.equals(firstSinalRange, "lte")){
                        String year = String.valueOf(Integer.parseInt(firstRange)+1);
                        if (Objects.equals(fieldRange, "dt_creation")){
                            response = elasticsearchClient.search(s -> s
                                    .index("wikipedia").from(from).size(size)
                                    .query(q -> q.bool(bq -> bq
                                            .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                    .lte(JsonData.of(year))
                                            ))
                                            .must(matchQuery)
                                    )), ObjectNode.class
                            );
                        }else{
                            response = elasticsearchClient.search(s -> s
                                    .index("wikipedia").from(from).size(size)
                                    .query(q -> q.bool(bq -> bq
                                            .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                    .lte(JsonData.of(firstRange))
                                            ))
                                            .must(matchQuery)
                                    )), ObjectNode.class
                            );
                        }

                    }else if (Objects.equals(firstSinalRange, "gt")){
                        if (Objects.equals(fieldRange, "dt_creation")){
                            response = elasticsearchClient.search(s -> s
                                    .index("wikipedia").from(from).size(size)
                                    .query(q -> q.bool(bq -> bq
                                            .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                    .gt(JsonData.of(firstRange + "-12-31"))
                                            ))
                                            .must(matchQuery)
                                    )), ObjectNode.class
                            );
                        }else{
                            response = elasticsearchClient.search(s -> s
                                    .index("wikipedia").from(from).size(size)
                                    .query(q -> q.bool(bq -> bq
                                            .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                    .gt(JsonData.of(firstRange))
                                            ))
                                            .must(matchQuery)
                                    )), ObjectNode.class
                            );
                        }
                    }else if (Objects.equals(firstSinalRange, "lt")){
                        response = elasticsearchClient.search(s -> s
                                .index("wikipedia").from(from).size(size)
                                .query(q -> q.bool(bq -> bq
                                        .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                .lt(JsonData.of(firstRange))
                                        ))
                                        .must(matchQuery)
                                )), ObjectNode.class
                        );
                    }else if (Objects.equals(firstSinalRange, "equal")){
                        String gthan = String.valueOf(Integer.parseInt(firstRange)-1);
                        //System.out.println(gthan);
                        String lthan = String.valueOf(Integer.parseInt(firstRange)+1);
                        //System.out.println(lthan);
                        String year = String.valueOf(Integer.parseInt(firstRange)-1);
                        if (Objects.equals(fieldRange, "dt_creation")){
                            response = elasticsearchClient.search(s -> s
                                    .index("wikipedia").from(from).size(size)
                                    .query(q -> q.bool(bq -> bq
                                            .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                    .gt(JsonData.of(year + "-12-31"))
                                                    .lt(JsonData.of(firstRange+"-12-31"))
                                            ))
                                            .must(matchQuery)
                                    )), ObjectNode.class
                            );
                        }else{
                            response = elasticsearchClient.search(s -> s
                                    .index("wikipedia").from(from).size(size)
                                    .query(q -> q.bool(bq -> bq
                                            .filter(fb -> fb.range(r -> r.field(fieldRange)
                                                    .gt(JsonData.of(gthan))
                                                    .lt(JsonData.of(lthan))
                                            ))
                                            .must(matchQuery)
                                    )), ObjectNode.class
                            );
                        }
                    }
                }



            }else{ // MatchQuery / PADRÃO
                if(Objects.equals(sortOrder, "ASC")) {
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchQuery).sort(so -> so
                                    .field(FieldSort.of(f -> f
                                            .field(sortBy)
                                            .order(SortOrder.Asc))
                                    )), ObjectNode.class
                    );
                } else if (Objects.equals(sortOrder, "DESC")) {
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchQuery).sort(so -> so
                                    .field(FieldSort.of(f -> f
                                            .field(sortBy)
                                            .order(SortOrder.Desc))
                                    )), ObjectNode.class
                    );
                }else { //NORMAL / PADRÃO - score
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchQuery), ObjectNode.class
                    );
                }
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return response;
    }
}
