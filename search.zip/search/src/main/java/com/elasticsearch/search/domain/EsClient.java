package com.elasticsearch.search.domain;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.FieldSort;
import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.query_dsl.*;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.json.JsonData;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import nl.altindag.ssl.SSLFactory;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.client.RestClient;
import org.springframework.stereotype.Component;


import java.io.IOException;
import java.time.LocalDate;

@Component
public class EsClient {
    private ElasticsearchClient elasticsearchClient;

    public EsClient() {
        createConnection();
    }

    private void createConnection() {
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();

        String USER = "elastic";
        String PWD = "user123";
        credentialsProvider.setCredentials(AuthScope.ANY,
            new UsernamePasswordCredentials(USER, PWD));

        SSLFactory sslFactory = SSLFactory.builder()
            .withUnsafeTrustMaterial()
            .withUnsafeHostnameVerifier()
            .build();

        RestClient restClient = RestClient.builder(
                new HttpHost("localhost", 9200, "https"))
            .setHttpClientConfigCallback((HttpAsyncClientBuilder httpClientBuilder) -> httpClientBuilder
                .setDefaultCredentialsProvider(credentialsProvider)
                .setSSLContext(sslFactory.getSslContext())
                .setSSLHostnameVerifier(sslFactory.getHostnameVerifier())
            ).build();

        ElasticsearchTransport transport = new RestClientTransport(
            restClient,
            new JacksonJsonpMapper()
        );

        elasticsearchClient = new co.elastic.clients.elasticsearch.ElasticsearchClient(transport);
    }

    public SearchResponse search(String query, int page, int sortOrder, String sortBy, int queryType, String sortOptions) {
        //                                             Buscando no campo content
        Query matchQuery = MatchQuery.of(q -> q.field("content").query(query))._toQuery();
        Query matchPhrase = MatchPhraseQuery.of(q -> q.field("content").query(query))._toQuery();

        int size = 10;
        int from = size*(page - 1);

        //BoolQuery boolQuery = BoolQuery.of(b -> b.must(matchQuery));

        /*
        ObjectMapper objectMapper = new ObjectMapper();
        JsonData numberFilter;
        try {
            // Converter a String para JsonData
            numberFilter = JsonData.fromJson(String.valueOf(objectMapper.readTree("3")));
        } catch (IOException e) {
            throw new IllegalArgumentException("Erro ao converter a string para JsonData", e);
        }
        RangeQuery rangeQuery = RangeQuery.of(q -> q
                        .field("number")
                        .gte(numberFilter));*/



        SearchResponse<ObjectNode> response;
        try {
            if( sortOrder == 1 ){ // 1 == ASC
                if(queryType == 2){
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchPhrase).sort(so -> so
                                    .field(FieldSort.of(f -> f
                                            .field(sortBy)
                                            .order(SortOrder.Asc))
                                    )), ObjectNode.class
                    );
                }else{
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchQuery).sort(so -> so
                                    .field(FieldSort.of(f -> f
                                            .field(sortBy)
                                            .order(SortOrder.Asc))
                                    )), ObjectNode.class
                    );
                }

            }else if(sortOrder == 2){ //2 == DESC
                if(queryType == 2){
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchPhrase).sort(so -> so
                                    .field(FieldSort.of(f -> f
                                            .field(sortBy)
                                            .order(SortOrder.Desc))
                                    )), ObjectNode.class
                    );
                }else{
                    if(queryType == 2){
                        response = elasticsearchClient.search(s -> s
                                .index("wikipedia").from(from).size(size)
                                .query(matchPhrase).sort(so -> so
                                        .field(FieldSort.of(f -> f
                                                .field(sortBy)
                                                .order(SortOrder.Desc))
                                        )), ObjectNode.class
                        );
                    }else{
                        response = elasticsearchClient.search(s -> s
                                .index("wikipedia").from(from).size(size)
                                .query(matchQuery).sort(so -> so
                                        .field(FieldSort.of(f -> f
                                                .field(sortBy)
                                                .order(SortOrder.Desc))
                                        )), ObjectNode.class
                        );
                    }

                }

            }else{ //3 ou qualquer item == ordenação por score
                if(queryType == 2){
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchPhrase), ObjectNode.class
                    );
                }else{
                    /*
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(matchQuery), ObjectNode.class
                    );*/
                    //RangeQuery e BoolQuery
                    response = elasticsearchClient.search(s -> s
                            .index("wikipedia").from(from).size(size)
                            .query(q -> q.bool(bq -> bq
                                            .filter(fb -> fb.range(r -> r.field("reading_time").
                                                            gte(JsonData.of(3))
                                                            .lte(JsonData.of(4))
                                                    )
                                            )
                                    .must(matchQuery)
                            )), ObjectNode.class
                    );
                }

            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return response;
    }
}
