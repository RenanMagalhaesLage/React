package com.elasticsearch.search.domain;

import co.elastic.clients.elasticsearch.ElasticsearchClient;
import co.elastic.clients.elasticsearch._types.FieldSort;
import co.elastic.clients.elasticsearch._types.SortOrder;
import co.elastic.clients.elasticsearch._types.query_dsl.*;
import co.elastic.clients.elasticsearch.core.SearchResponse;
import co.elastic.clients.elasticsearch.core.search.Highlight;
import co.elastic.clients.elasticsearch.core.search.HighlightField;
import co.elastic.clients.json.JsonData;
import co.elastic.clients.json.jackson.JacksonJsonpMapper;
import co.elastic.clients.transport.ElasticsearchTransport;
import co.elastic.clients.transport.rest_client.RestClientTransport;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import nl.altindag.ssl.SSLFactory;
import org.apache.http.HttpHost;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.elasticsearch.client.RestClient;
//import org.elasticsearch.index.query.BoolQueryBuilder;
//import org.elasticsearch.index.query.MatchQueryBuilder;
import org.springframework.stereotype.Component;


import javax.swing.text.Highlighter;
import java.io.IOException;
import java.time.LocalDate;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

@Component
public class EsClient {
    private ElasticsearchClient elasticsearchClient;

    public EsClient() {
        createConnection();
    }

    private void createConnection() {
        CredentialsProvider credentialsProvider = new BasicCredentialsProvider();

        String USER = "elastic";
        String PWD = "user123";
        credentialsProvider.setCredentials(AuthScope.ANY,
            new UsernamePasswordCredentials(USER, PWD));

        SSLFactory sslFactory = SSLFactory.builder()
            .withUnsafeTrustMaterial()
            .withUnsafeHostnameVerifier()
            .build();

        RestClient restClient = RestClient.builder(
                new HttpHost("localhost", 9200, "https"))
            .setHttpClientConfigCallback((HttpAsyncClientBuilder httpClientBuilder) -> httpClientBuilder
                .setDefaultCredentialsProvider(credentialsProvider)
                .setSSLContext(sslFactory.getSslContext())
                .setSSLHostnameVerifier(sslFactory.getHostnameVerifier())
            ).build();

        ElasticsearchTransport transport = new RestClientTransport(
            restClient,
            new JacksonJsonpMapper()
        );

        elasticsearchClient = new ElasticsearchClient(transport);
    }

    public SearchResponse search(String query, int page, String sortOrder, String sortBy, int queryType, String rangeOptions, String boolOptions) {
        //                                             Buscando no campo content
        //Query matchQuery = MatchQuery.of(q -> q.field("content").query(query))._toQuery();
        // TO DO: Editar para quando a pessoa digitar aspas
        //Query matchPhrase = MatchPhraseQuery.of(q -> q.field("content").query(query))._toQuery();

        int size = 10;
        int from = size*(page - 1);

        /* Identificando uso de MatchPhrase*/

        List<String> listmatchPhrase = new ArrayList<>();
        Pattern padrao1 = Pattern.compile("\"(.*?)\"");
        Matcher matcher1 = padrao1.matcher(query);
        while (matcher1.find()) {
            listmatchPhrase.add(matcher1.group(1));
        }

        /* Identificando uso do matchquery */
        Pattern padrao2 = Pattern.compile("\"([^\"]*)\"|\\p{L}+");
        Matcher matcher2 = padrao2.matcher(query);
        List<String> listmatchQuery = new ArrayList<>();
        while (matcher2.find()) {
            String palavra = matcher2.group();
            if (!palavra.startsWith("\"")) {
                listmatchQuery.add(palavra);
            }
        }

        /* BOOLQUERY */

        String numberOperation = boolOptions.split("/")[0];
        String query1 = boolOptions.split("/")[1];
        String query2 = boolOptions.split("/")[2];
        String query3 = boolOptions.split("/")[3];
        Query matchQuery1 = MatchQuery.of(q -> q.field("content").query(query1))._toQuery();
        Query matchQuery2 = MatchQuery.of(q -> q.field("content").query(query2))._toQuery();
        Query matchQuery3 = MatchQuery.of(q -> q.field("content").query(query3))._toQuery();

        BoolQuery.Builder boolQueryBuilder = new BoolQuery.Builder();

        /* Construindo a BoolQuery */
        if(queryType == 2){
            switch (numberOperation) {
                case "7":
                    // must, should e must_not
                    boolQueryBuilder.must(matchQuery1).should(matchQuery2).mustNot(matchQuery3);
                    break;
                case "2":
                    // apenas should
                    boolQueryBuilder.should(matchQuery2);
                    break;
                case "3":
                    // apenas must_not
                    boolQueryBuilder.mustNot(matchQuery3);
                    break;
                case "4":
                    // must e should
                    boolQueryBuilder.must(matchQuery1).should(matchQuery2);
                    break;
                case "5":
                    // must e must_not
                    boolQueryBuilder.must(matchQuery1).mustNot(matchQuery3);
                    break;
                case "6":
                    // sould e must_not
                    boolQueryBuilder.should(matchQuery2).mustNot(matchQuery3);
                    break;
                default:
                    // apenas must
                    boolQueryBuilder.must(matchQuery1);
            }
        }

        /* MatchQuery e MatchPhrase */
        if(queryType == 1) {
            for (String queryPhrase : listmatchPhrase) {
                Query matchPhrase = MatchPhraseQuery.of(q -> q.field("content").query(queryPhrase))._toQuery();
                boolQueryBuilder.must(matchPhrase);
            }
            for(String queryMatch : listmatchQuery){
                Query matchQuery = MatchQuery.of(q -> q.field("content").query(queryMatch))._toQuery();
                boolQueryBuilder.must(matchQuery);
            }
        }    


        /* RANGEQUERY */

        String fieldRange = rangeOptions.split("/")[0];
        String quantRange = rangeOptions.split("/")[1];
        String firstSinalRange = rangeOptions.split("/")[2];
        String firstRange = rangeOptions.split("/")[3];
        String secondSinalRange = rangeOptions.split("/")[4];
        String secondRange = rangeOptions.split("/")[5];

        List<Query> listFilter = new ArrayList<>();
        Query filterQuery = RangeQuery.of(q -> q.field("reading_time").gte(JsonData.of(5)))._toQuery();
        if(queryType == 3){
            if(Objects.equals(quantRange, "2")){
                if(Objects.equals(firstSinalRange, "gte") && Objects.equals(secondSinalRange, "lte")){
                    filterQuery = RangeQuery.of(q -> q.field(fieldRange).gte(JsonData.of(firstRange)).lte(JsonData.of(secondRange)))._toQuery();
                }else if (Objects.equals(firstSinalRange, "gte") && Objects.equals(secondSinalRange, "lt")) {
                    filterQuery = RangeQuery.of(q -> q.field(fieldRange).gte(JsonData.of(firstRange)).lt(JsonData.of(secondRange)))._toQuery();
                }else if (Objects.equals(firstSinalRange, "gt") && Objects.equals(secondSinalRange, "lt")){
                    filterQuery = RangeQuery.of(q -> q.field(fieldRange).gt(JsonData.of(firstRange)).lt(JsonData.of(secondRange)))._toQuery();
                }else if (Objects.equals(firstSinalRange, "gt") && Objects.equals(secondSinalRange, "lte")){
                    filterQuery = RangeQuery.of(q -> q.field(fieldRange).gt(JsonData.of(firstRange)).lte(JsonData.of(secondRange)))._toQuery();
                }
            }else{
                if(Objects.equals(firstSinalRange, "gte")){
                    filterQuery = RangeQuery.of(q -> q.field(fieldRange).gte(JsonData.of(firstRange)))._toQuery();
                }else if (Objects.equals(firstSinalRange, "lte")){
                    filterQuery = RangeQuery.of(q -> q.field(fieldRange).lte(JsonData.of(firstRange)))._toQuery();
                }else if (Objects.equals(firstSinalRange, "gt")){
                    filterQuery = RangeQuery.of(q -> q.field(fieldRange).gt(JsonData.of(firstRange)))._toQuery();
                }else if (Objects.equals(firstSinalRange, "lt")){
                    filterQuery = RangeQuery.of(q -> q.field(fieldRange).lt(JsonData.of(firstRange)))._toQuery();
                }
            }
            listFilter.add(filterQuery);
            for (String queryPhrase : listmatchPhrase) {
                Query matchPhrase = MatchPhraseQuery.of(q -> q.field("content").query(queryPhrase))._toQuery();
                boolQueryBuilder.must(matchPhrase).filter(listFilter);
            }
            for(String queryMatch : listmatchQuery){
                Query matchQuery = MatchQuery.of(q -> q.field("content").query(queryMatch))._toQuery();
                boolQueryBuilder.must(matchQuery).filter(listFilter);
            }
            //boolQueryBuilder.must(matchQuery).filter(listFilter);
        }

        /* HIGHLIGHT */

        HighlightField.Builder hlfield =new HighlightField.Builder().matchedFields("content")
                .preTags("<strong>")
                .postTags("</strong>");
        Map<String, HighlightField> fieldsMap = new HashMap<>();
        fieldsMap.put("content", hlfield.build());
        Highlight.Builder highlight = new Highlight.Builder().numberOfFragments(1).fragmentSize(500).fields(fieldsMap);

        SearchResponse<ObjectNode> response = null;
        try {
            response = elasticsearchClient.search(s -> s
                    .index("wikipedia").from(from).size(size)
                    .query(q -> q
                            .bool(boolQueryBuilder.build())
                    ).highlight(highlight.build()), ObjectNode.class
            );
            /*
            if (queryType == 3) { // BoolQuery
                response = elasticsearchClient.search(s -> s
                        .index("wikipedia").from(from).size(size)
                        .query(q -> q
                                .bool(boolQueryBuilder.build())
                        ).highlight(highlight.build()), ObjectNode.class
                );
            }else if (queryType == 4){ // RangeQuery
                response = elasticsearchClient.search(s -> s
                        .index("wikipedia").from(from).size(size)
                        .query(q -> q
                                .bool(boolQueryBuilder.build())
                        ).highlight(highlight.build()), ObjectNode.class
                );
            }else{

            }*/

        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return response;
    }
}
